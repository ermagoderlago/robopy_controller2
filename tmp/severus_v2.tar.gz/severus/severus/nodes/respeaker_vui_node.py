#!/usr/bin/env python3
"""
Nodo VUI (Voice User Interface) per ReSpeaker Lite via USB Audio nativo.
=======================================================================
Versione 5.1 — Raw int16 pipeline (Stable & Clean)

Changelog v5.1:
  [#1] Pulizia codice morto, rimosse inizializzazioni doppie e metodi orfani.
  [#2] Sincronizzazione versione log di avvio.

Changelog v5.0:
  [#1] Rimosso intero stack DSP float32 (SciPy Butterworth, sosfilt, scalatura):
       Porcupine e WebRTC VAD ricevono il segnale int16 grezzo dal mic.
  [#2] CPU usage su Pi5: da ~40% a ~2-3%.
  [#3] Rimosse tutte le stampe di debug nel hot-path del callback.

Changelog v3.0:
  [#1] VAD gate WebRTC con ring buffer pre-roll 500 ms
  [#2] CHUNK_SIZE=960 (3 frame VAD esatti da 320 campioni)
  [#3] Zero allocazioni heap nel callback audio (buffer pre-allocati in __init__)
  [#4] Gestione TTS con reset completo dello stato VAD

Changelog v2.5 (legacy):
  [#1] threading.Event per _tts_active e _listening: atomici, zero Lock nel callback
  [#2] Coda audio output maxsize 512
  [#3] Contatore errori consecutivi nel callback: log CRITICAL oltre soglia
"""

import os
import pickle
import sys
sys.modules['pickle5'] = pickle
import threading
import queue
import time
import audioop

# Nuovi import per DSP
import numpy as np
import webrtcvad

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
from std_msgs.msg import Bool, String
from severus.msg import AudioData            # classe AudioData usata per _pub_speech
import pyaudio
import pvporcupine

try:
    from dotenv import load_dotenv
    # Fix: Usa il path assoluto per caricare .env, poiché in ROS2 la CWD può variare.
    load_dotenv("/mnt/ssd/severus_host/.env", override=True)
except ImportError:
    pass

# ---------------------------------------------------------------------------
# Costanti globali (fuori dalla classe)
# ---------------------------------------------------------------------------
SAMPLE_RATE        = 16000
CHUNK_SIZE         = 960    # frames_per_buffer in pyaudio.open() — cambiarli insieme
FRAME_SIZE         = 320    # campioni per frame VAD (20 ms @ 16 kHz)

# Ring buffer: abbastanza grande da coprire pause brevi tra frasi (2.5 sec)
PRE_ROLL_FRAMES    = 25                       # 25 × 20 ms = 500 ms di pre-roll
MAX_RING_FRAMES    = PRE_ROLL_FRAMES + 100    # 125 × 20 ms = 2.5 sec totali

MIN_SPEECH_FRAMES  = 25    # frame VAD=True consecutivi per aprire il gate
MAX_SILENCE_FRAMES = 15    # frame VAD=False consecutivi per chiudere il gate
MAX_RESIDUAL       = FRAME_SIZE   # dimensione buffer residuo (= FRAME_SIZE)

# Pre-roll: bytearray pre-allocato (int16 = 2 byte/campione)
PRE_ROLL_BYTES     = PRE_ROLL_FRAMES * FRAME_SIZE * 2

# Numero di errori consecutivi nel callback prima di loggare CRITICAL
_CALLBACK_ERROR_THRESHOLD = 20

# Soglia dimensione chunk (bytes) per distinguere Native Audio da TTS classico.
_NATIVE_AUDIO_CHUNK_THRESHOLD = 6144

# Sample rate del Native Audio di Gemini Live API (24kHz mono PCM int16)
_NATIVE_AUDIO_RATE = 24000
# Sample rate del TTS classico e del microfono
_STD_AUDIO_RATE    = 16000


def _load_keys():
    """Carica le chiavi API da setup_keys.sh centrale."""
    setup_keys_path = '/mnt/ssd/severus_host/setup_keys.sh'
    keys_to_load = [
        'GEMINI_API_KEY', 'DEEPSEEK_API_KEY', 'PICOVOICE_API_KEY',
        'GOOGLE_APPLICATION_CREDENTIALS', 'HA_TOKEN'
    ]
    if os.path.exists(setup_keys_path):
        try:
            with open(setup_keys_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'): continue
                    for key_name in keys_to_load:
                        clean_line = line.replace('export ', '').strip()
                        if clean_line.startswith(f'{key_name}='):
                            val = clean_line.split('=', 1)[1].strip().strip('"').strip("'")
                            if '#' in val: val = val[:val.index('#')].strip()
                            os.environ[key_name] = val
        except Exception:
            pass


class ReSpeakerVUINode(Node):

    def __init__(self):
        super().__init__('respeaker_vui_node')
        self.get_logger().info("--- ReSpeaker VUI Node v5.1 (Optimized Native Pipeline) ---")
        _load_keys()

        # ------------------------------------------------------------------ #
        # Parametri ROS 2
        # ------------------------------------------------------------------ #
        self.declare_parameter('stt_gain',              1.2)
        self.declare_parameter('noise_gate_threshold',  400.0)
        self.declare_parameter('wakeword_sensitivity',  0.92)  # [v4.0] default alzato
        self.declare_parameter('playback_prebuffer',    2)
        self.declare_parameter('listen_timeout_sec',    10.0)
        self.declare_parameter('access_key',            '')
        self.declare_parameter('device_name',           'ReSpeaker')
        self.declare_parameter('sample_rate',           16000)
        self.declare_parameter('enable_vad_gate',       True)   # [v3.0] parametro debug

        self._cfg_enable_vad_gate = self.get_parameter('enable_vad_gate').get_parameter_value().bool_value

        access_key               = self.get_parameter('access_key').get_parameter_value().string_value
        if not access_key:
            access_key = os.environ.get('PICOVOICE_API_KEY', '')
            if access_key:
                self.get_logger().info("Picovoice API Key caricata dalle variabili d'ambiente.")

        self.device_name_target  = self.get_parameter('device_name').get_parameter_value().string_value
        self.sample_rate         = self.get_parameter('sample_rate').get_parameter_value().integer_value
        self.stt_gain            = self.get_parameter('stt_gain').get_parameter_value().double_value
        self.noise_gate_threshold = self.get_parameter('noise_gate_threshold').get_parameter_value().double_value
        sensitivity              = self.get_parameter('wakeword_sensitivity').get_parameter_value().double_value
        self._listen_timeout_sec = self.get_parameter('listen_timeout_sec').get_parameter_value().double_value
        self._prebuffer_size     = self.get_parameter('playback_prebuffer').get_parameter_value().integer_value

        if not access_key:
            self.get_logger().error("PICOVOICE_API_KEY non trovata! Inseriscila nel launch file o in setup_keys.sh")
            self.porcupine = None
        else:
            self.porcupine = None

        # ------------------------------------------------------------------ #
        # Porcupine
        # ------------------------------------------------------------------ #
        self.get_logger().info("Inizializzazione Porcupine...")
        try:
            from ament_index_python.packages import get_package_share_directory
            pkg_share    = get_package_share_directory('severus')
            keyword_path = os.path.join(pkg_share, 'config', 'wake_word', 'marcus.ppn')
            model_path   = os.path.join(pkg_share, 'config', 'wake_word', 'porcupine_params_it.pv')

            if os.path.exists(keyword_path) and os.path.exists(model_path):
                self.porcupine = pvporcupine.create(
                    access_key=access_key,
                    keyword_paths=[keyword_path],
                    model_path=model_path,
                    sensitivities=[sensitivity]
                )
                self.get_logger().info(f"Wake word: {keyword_path} | sensitivity={sensitivity}")
            else:
                self.porcupine = pvporcupine.create(
                    access_key=access_key,
                    keywords=['porcupine'],
                    sensitivities=[sensitivity]
                )
                self.get_logger().warning("Keyword 'marcus.ppn' non trovata, uso 'porcupine'.")
        except Exception as e:
            self.get_logger().error(f"Errore Porcupine: {e}")
            self.porcupine = None

        # Porcupine frame_length (normalmente 512).
        # CHUNK_SIZE=960 è compatibile con Porcupine.
        if self.porcupine:
            self.frame_length = self.porcupine.frame_length
        else:
            self.frame_length = 512

        # ------------------------------------------------------------------ #
        # Buffer di lavoro NumPy (solo interi nativi, zero float)
        # ------------------------------------------------------------------ #
        self._int16_vad_buf = np.empty(CHUNK_SIZE, dtype=np.int16)
        self._silence_buf   = np.zeros(FRAME_SIZE, dtype=np.int16)

        # [DSP-HOT] Residuo inter-callback (attivo sempre)
        self._vad_residual_buf = np.empty(MAX_RESIDUAL, dtype=np.int16)
        self._vad_residual_len = 0
        self._assembly_buf     = np.empty(FRAME_SIZE, dtype=np.int16)  # pre-allocato, zero alloc nel callback

        # [DSP-HOT] Ring buffer pre-roll (2.5 sec — copre pause tra frasi)
        self._speech_ring    = np.zeros((MAX_RING_FRAMES, FRAME_SIZE), dtype=np.int16)
        self._ring_write_idx = 0

        # [DSP-HOT] Pre-roll bytearray pre-allocato (evita allocazioni frequenti)
        self._preroll_ba = bytearray(PRE_ROLL_BYTES)

        # [v3.1] Residuo Porcupine (evita perdita campioni wake-word)
        self._porcupine_residual_buf = np.empty(self.frame_length, dtype=np.int16)
        self._porcupine_residual_len = 0
        self._porcupine_assembly_buf = np.empty(self.frame_length, dtype=np.int16)

        # [v3.0] Stato VAD
        self._vad                 = webrtcvad.Vad(3)
        self._speech_frame_count  = 0
        self._silence_frame_count = 0
        self._is_speech_active    = False

        # Contatori diagnostica (inizializzati qui, non con hasattr nel hot-path)
        self._rms_chunk_count = 0
        self._stt_chunk_count = 0

        # [v3.0] Stato TTS — scritto e letto SOLO nel callback audio (no race condition)
        self._tts_active     = False
        self._tts_start_time = 0.0

        # ------------------------------------------------------------------ #
        # [v2.5 #1] Stato VUI con threading.Event
        # ------------------------------------------------------------------ #
        self.stt_gain            = self.get_parameter('stt_gain').get_parameter_value().double_value
        self._prebuffer_size     = self.get_parameter('playback_prebuffer').get_parameter_value().integer_value
        self._last_playback_time = 0.0

        self._ev_listening = threading.Event()
        self._ev_tts       = threading.Event()
        self._shutdown     = False
        self._listen_timer = None

        # [v2.5 #3] Contatore errori consecutivi nel callback
        self._consecutive_errors = 0

        # Thread-safety output stream
        self._out_lock = threading.Lock()

        # Coda audio output
        self._audio_out_queue = queue.Queue(maxsize=512)
        self._playback_thread = threading.Thread(
            target=self._playback_worker, daemon=True, name='vui_playback')
        self._playback_thread.start()

        # ------------------------------------------------------------------ #
        # Publisher / Subscriber
        # ------------------------------------------------------------------ #
        qos_profile_audio = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            history=HistoryPolicy.KEEP_LAST,
            depth=10
        )
        self.ww_pub       = self.create_publisher(String,    '/wake_word',              10)
        self.mic_mute_pub = self.create_publisher(Bool,      '/ai/input/mic_mute',      10)
        self.audio_pub    = self.create_publisher(AudioData, '/ai/input/audio_chunk',  qos_profile_audio)
        self.led_pub      = self.create_publisher(String,    '/respeaker/led_command',  10)

        # [v3.0] _pub_speech alias per il VAD gate (usa lo stesso topic audio_pub)
        self._pub_speech  = self.audio_pub

        self.create_subscription(Bool,      '/ai/tts/speaking',         self._tts_speaking_cb,  10)
        self.create_subscription(AudioData, '/respeaker/speaker_audio', self._speaker_audio_cb, 10)
        self.create_subscription(Bool,      '/ai/input/mic_mute',       self._mic_mute_cb,      10)

        # ------------------------------------------------------------------ #
        # PyAudio — usa CHUNK_SIZE come frames_per_buffer
        # ------------------------------------------------------------------ #
        self.pa = pyaudio.PyAudio()
        input_device_index, output_device_index = self._find_audio_devices()

        if input_device_index is None:
            self.get_logger().warning(
                f"Device '{self.device_name_target}' non trovato, uso default.")

        # [v3.8] Rileva il sample rate nativo HW del device di output
        # Il DAC del ReSpeaker Lite lavora a 48kHz. PyAudio accetta 16kHz
        # ma il chip lo ignora: serve resampling esplicito.
        self._out_hw_rate = self.sample_rate  # fallback
        if output_device_index is not None:
            try:
                dev_info = self.pa.get_device_info_by_index(output_device_index)
                self._out_hw_rate = int(dev_info.get('defaultSampleRate', self.sample_rate))
                self.get_logger().info(
                    f"🔊 Output device HW native rate: {self._out_hw_rate} Hz")
            except Exception:
                pass

        try:
            self.in_stream = self.pa.open(
                rate=SAMPLE_RATE,
                channels=2,
                format=pyaudio.paInt16,
                input=True,
                input_device_index=input_device_index,
                frames_per_buffer=CHUNK_SIZE,          # [v3.0] CHUNK_SIZE=960
                stream_callback=self._audio_input_callback,
                start=False
            )
            self.get_logger().info(f"🎤 Input stream (mic) aperto! (Idx={input_device_index})")
        except Exception as e:
            self.get_logger().error(f"Errore apertura input stream: {e}. STT non funzionerà.")
            self.in_stream = None

        try:
            self.out_stream = self.pa.open(
                rate=self._out_hw_rate,
                channels=2,
                format=pyaudio.paInt16,
                output=True,
                output_device_index=output_device_index
            )
            self.get_logger().info(
                f"✅ Output stream aperto a {self._out_hw_rate} Hz Stereo "
                f"(HW native: {self._out_hw_rate} Hz)")
        except Exception as e:
            self.get_logger().error(f"Errore fatale apertura output stream: {e}")
            self.out_stream = None

        if self.in_stream:
            self.in_stream.start_stream()
        self.set_led('IDLE')

        # Stato playback
        self._playback_ratecv_state = None
        self._last_audio_source     = None

        self.get_logger().info(
            f"VUI Node pronto | CHUNK_SIZE={CHUNK_SIZE} | FRAME_SIZE={FRAME_SIZE} | "
            f"PRE_ROLL_FRAMES={PRE_ROLL_FRAMES} | sensitivity={sensitivity} | "
            f"stt_gain={self.stt_gain}"
        )



    # ------------------------------------------------------------------ #
    # Worker thread riproduzione
    # ------------------------------------------------------------------ #
    def _playback_worker(self):
        self.get_logger().info("Avvio playback_worker con Jitter Buffer Adattivo")
        _chunks_played = 0

        while not self._shutdown:
            try:
                if self._audio_out_queue.empty():
                    time.sleep(0.005)  # idle: 5ms ok, non spreca CPU
                    continue

                qsize = self._audio_out_queue.qsize()

                try:
                    first_chunk = self._audio_out_queue.queue[0]
                    is_live = len(first_chunk) < _NATIVE_AUDIO_CHUNK_THRESHOLD
                except (IndexError, AttributeError):
                    is_live = True

                required_chunks = 2 if is_live else self._prebuffer_size
                
                # [v4.0] Ottimizzazione dinamica per chunk grandi (TTS)
                # Se il primo chunk è gigante (>12KB, circa 400ms), partiamo subito
                # per evitare i "scatti" dovuti all'attesa del secondo secondo di audio.
                if len(first_chunk) > 12288:
                    required_chunks = 1

                if qsize < required_chunks:
                    time.sleep(0.001)  # [FIX] da 5ms → 1ms: meno jitter
                    continue

                # [DEBUG] Log inizio drain (solo all'inizio di ogni burst)
                if _chunks_played == 0 or _chunks_played % 50 == 0:
                    self.get_logger().info(
                        f"🔈 [PLAYBACK] drain start: q={qsize}, "
                        f"required={required_chunks}, live={is_live}")

                # [FIX] Rimosso il break — svuota la coda in una raffica continua
                # così lo stream PyAudio non va mai in underrun
                while not self._audio_out_queue.empty() and not self._shutdown:
                    try:
                        pcm_bytes = self._audio_out_queue.get_nowait()
                        if self.out_stream is not None:
                            with self._out_lock:
                                self.out_stream.write(pcm_bytes)
                                _chunks_played += 1
                    except queue.Empty:
                        break

            except Exception as e:
                self.get_logger().error(f"Errore playback worker: {e}")
                time.sleep(0.1)

    def _play_audio(self, pcm_bytes: bytes):
        self._last_playback_time = time.time()
        try:
            self._audio_out_queue.put_nowait(pcm_bytes)
        except queue.Full:
            self.get_logger().warning("Coda audio piena, frame saltato.")

    def _generate_beep(self, freq: float = 1000.0, duration: float = 0.15) -> bytes:
        t    = np.linspace(0, duration, int(SAMPLE_RATE * duration), False)
        fade = np.linspace(1.0, 0.0, len(t))
        mono = (np.sin(2 * np.pi * freq * t) * fade * 3276).astype(np.int16)
        return np.repeat(mono, 2).tobytes()

    # ------------------------------------------------------------------ #
    # LED
    # ------------------------------------------------------------------ #
    def set_led(self, effect: str):
        msg = String()
        msg.data = f"LED_EFFECT:{effect}\n"
        self.led_pub.publish(msg)

    # ------------------------------------------------------------------ #
    # Subscriber callbacks
    # ------------------------------------------------------------------ #
    def _tts_speaking_cb(self, msg: Bool):
        if msg.data:
            self._ev_tts.set()
            self.set_led('THINKING')
        else:
            self._ev_tts.clear()
            if not self._ev_listening.is_set():
                self.set_led('IDLE')

    def _mic_mute_cb(self, msg: Bool):
        if msg.data:
            self._stop_listen_timer()
            self._ev_listening.clear()
            self.set_led('IDLE')
        else:
            self._ev_listening.set()
            self.set_led('LISTENING')
            self._start_listen_timer()  # [FIX] Start auto-timeout when unmuted

    def _speaker_audio_cb(self, msg: AudioData):
        if self._shutdown or not msg.data:
            return
        try:
            raw_bytes = bytes(msg.data)

            # [DEBUG] Log primo chunk e ogni 20 successivi
            if not hasattr(self, '_audio_chunk_count'): self._audio_chunk_count = 0
            self._audio_chunk_count += 1
            is_first = (self._audio_chunk_count == 1)

            is_live = len(raw_bytes) < _NATIVE_AUDIO_CHUNK_THRESHOLD
            current_source = "live" if is_live else "tts"

            if self._last_audio_source != current_source:
                self._playback_ratecv_state = None
                self._last_audio_source = current_source
                self.get_logger().info(f"🔊 [SPEAKER] Cambio sorgente: {current_source}")

            if self.out_stream and self._out_hw_rate == 48000:
                input_rate = _NATIVE_AUDIO_RATE if is_live else _STD_AUDIO_RATE
                audio_48k_bytes, self._playback_ratecv_state = audioop.ratecv(
                    raw_bytes, 2, 1, input_rate, 48000, self._playback_ratecv_state
                )
                audio_48k_np = np.frombuffer(audio_48k_bytes, dtype=np.int16)
                final_audio = np.repeat(audio_48k_np, 2).tobytes()
                audio_ref = audio_48k_np
            else:
                audio_mono_np = np.frombuffer(raw_bytes, dtype=np.int16)
                final_audio = np.repeat(audio_mono_np, 2).tobytes()
                audio_ref = audio_mono_np

            rms = np.sqrt(np.mean(audio_ref.astype(np.float32) ** 2))
            intensity = int(min(255, (rms / 2000.0) * 255.0))

            if is_first or self._audio_chunk_count % 20 == 0:
                qsize = self._audio_out_queue.qsize()
                self.get_logger().info(
                    f"🔊 [SPEAKER] chunk #{self._audio_chunk_count}: "
                    f"{len(raw_bytes)}B -> {len(final_audio)}B "
                    f"(src={current_source}, HW={self._out_hw_rate}Hz, "
                    f"rms={rms:.0f}, q={qsize})")

            if intensity > 10:
                self.set_led(f"SPEAKING:{intensity}")

            self._play_audio(final_audio)
        except Exception as e:
            self.get_logger().error(f"Errore speaker_audio_cb: {e}", exc_info=True)

    # ------------------------------------------------------------------ #
    # Timeout listener
    # ------------------------------------------------------------------ #
    def _start_listen_timer(self):
        self._stop_listen_timer()
        self._listen_timer = self.create_timer(
            self._listen_timeout_sec, self._on_listen_timeout)

    def _stop_listen_timer(self):
        if self._listen_timer is not None:
            self._listen_timer.cancel()
            self._listen_timer = None

    def _on_listen_timeout(self):
        self.get_logger().warning(
            f"Timeout ascolto ({self._listen_timeout_sec}s): reset IDLE automatico.")
        self._stop_listen_timer()
        self._ev_listening.clear()
        self.set_led('IDLE')
        mute_msg = Bool()
        mute_msg.data = True
        self.mic_mute_pub.publish(mute_msg)

    # ------------------------------------------------------------------ #
    # [v3.0] PUBBLICAZIONE ROS 2 — metodi VAD gate
    # ------------------------------------------------------------------ #
    def _publish_preroll(self) -> None:
        """
        Pubblica i PRE_ROLL_FRAMES frame come un singolo messaggio ROS 2.
        Usa memoryview su _preroll_ba per evitare copie intermedie.
        """
        mv = memoryview(self._preroll_ba)
        for i in range(PRE_ROLL_FRAMES):
            idx   = (self._ring_write_idx - PRE_ROLL_FRAMES + i) % MAX_RING_FRAMES
            start = i * FRAME_SIZE * 2
            end   = start + FRAME_SIZE * 2
            mv[start:end] = self._speech_ring[idx].tobytes()
        msg      = AudioData()
        msg.data = bytes(self._preroll_ba)   # copia necessaria per ROS 2
        self._pub_speech.publish(msg)

    def _publish_audio_frame(self, frame_int16: np.ndarray) -> None:
        msg      = AudioData()
        msg.data = frame_int16.tobytes()     # [DSP-HOT] tobytes() su view 320 campioni
        self._pub_speech.publish(msg)

    def _publish_end_of_speech(self) -> None:
        msg      = AudioData()
        msg.data = b''                       # frame vuoto = segnale end-of-speech per il LLM
        self._pub_speech.publish(msg)

    # ------------------------------------------------------------------ #
    # [v3.0] _process_vad_frame — eseguito nel hot-path del callback
    # ------------------------------------------------------------------ #
    def _process_vad_frame(self, frame_int16: np.ndarray) -> None:
        """
        Processa un singolo frame VAD da 320 campioni.
        Aggiorna ring buffer SEMPRE. Gestisce speech gate.
        Zero allocazioni heap.
        """
        # [DSP-HOT] aggiorna ring buffer SEMPRE (anche durante silenzio)
        np.copyto(self._speech_ring[self._ring_write_idx], frame_int16)
        self._ring_write_idx = (self._ring_write_idx + 1) % MAX_RING_FRAMES

        # [DSP-HOT] tobytes() inevitabile (API C) — solo su view da 320 campioni
        try:
            is_voice = self._vad.is_speech(frame_int16.tobytes(), SAMPLE_RATE)
        except ValueError as e:
            # ValueError = frame malformato: bug upstream — logga come errore
            self.get_logger().error(f'[VAD] frame malformato (bug): {e}')
            is_voice = False
        except Exception as e:
            self.get_logger().warn(f'[VAD] errore generico: {e}')
            is_voice = False

        if is_voice:
            self._speech_frame_count  += 1
            self._silence_frame_count  = 0

            if (self._speech_frame_count >= MIN_SPEECH_FRAMES
                    and not self._is_speech_active):
                self._is_speech_active = True
                self._publish_preroll()   # unico messaggio ROS 2 con 500 ms di pre-roll

            if self._is_speech_active:
                self._publish_audio_frame(frame_int16)
        else:
            self._speech_frame_count = 0
            if self._is_speech_active:
                self._silence_frame_count += 1
                if self._silence_frame_count >= MAX_SILENCE_FRAMES:
                    self._is_speech_active    = False
                    self._silence_frame_count = 0
                    self._publish_end_of_speech()

    # ------------------------------------------------------------------ #
    # [v3.1] Helper per rilevazione Wake Word
    # ------------------------------------------------------------------ #
    def _on_wakeword_detected(self):
        """Gestisce le azioni da compiere quando viene rilevata la wake word."""
        if self._ev_listening.is_set():
            return # Già in ascolto, evita beep multipli se la parola è ripetuta

        self.get_logger().info("WAKE WORD 'MARCUS' RILEVATA!")
        self._ev_listening.set()
        self.set_led('LISTENING')

        # Svuota la coda audio per interrompere eventuali messaggi in corso
        while not self._audio_out_queue.empty():
            try:
                self._audio_out_queue.get_nowait()
            except queue.Empty:
                break

        self._play_audio(self._generate_beep())
        self._start_listen_timer()

        # Comunica il cambio di stato ai nodi AI
        unmute_msg = Bool()
        unmute_msg.data = False
        self.mic_mute_pub.publish(unmute_msg)

        ww_msg = String()
        ww_msg.data = "detected"
        self.ww_pub.publish(ww_msg)

    # ------------------------------------------------------------------ #
    # Callback audio di input — eseguita dal thread interno PyAudio
    #
    # Target Pi5: ZERO allocazioni heap per frame.
    # Lettura stato via Event.is_set(): lock-free, ~10ns sul Pi5.
    # ------------------------------------------------------------------ #
    def _audio_input_callback(self, in_data, frame_count, time_info, status):
        if self._shutdown or self.porcupine is None:
            return (None, pyaudio.paContinue)

        try:
            # ---------------------------------------------------------- #
            # Mix L+R → mono int16 (stereo → CHUNK_SIZE campioni mono)
            # ---------------------------------------------------------- #
            # [DSP-HOT] frombuffer senza copia
            audio_stereo = np.frombuffer(in_data, dtype=np.int16)    # [DSP-HOT]
            # Stereo interleaved → Usiamo solo il canale sinistro (Left)
            # Questo evita la "Phase Cancellation".
            l_ch = audio_stereo[::2]
            n    = min(len(l_ch), CHUNK_SIZE)
            
            # Diagnostica Volume MIC (RMS ogni ~5s)
            self._rms_chunk_count += 1
            if self._rms_chunk_count % 80 == 0: # ~5s a 16kHz CHUNK=960
                rms_val  = np.sqrt(np.mean(l_ch[:n].astype(np.float32)**2))
                # Casta a int32 per evitare underflow negativo di np.int16
                peak_p2p = int(np.max(l_ch[:n])) - int(np.min(l_ch[:n]))
                self.get_logger().info(
                    f"🎤 [MIC] Volume (HW Raw): RMS={rms_val:.1f} | P2P={peak_p2p} "
                    f"(Channel: LEFT only)")
            
            # ---------------------------------------------------------- #
            # Invio diretto di l_ch al buffer VAD (nessuna attenuazione o filtro pesante)
            # ---------------------------------------------------------- #
            np.copyto(self._int16_vad_buf[:n], l_ch[:n])

            # ---------------------------------------------------------- #
            # [v3.0 — STEP A] Controllo TTS
            # Leggi _ev_tts UNA SOLA VOLTA per callback → variabile locale
            # ---------------------------------------------------------- #
            tts_now = self._ev_tts.is_set()
            tts_was = self._tts_active

            # Transizione False→True: registra timestamp nel callback stesso
            if tts_now and not tts_was:
                self._tts_start_time = time.monotonic()

            self._tts_active = tts_now

            if tts_now:
                self._speech_frame_count  = 0
                self._silence_frame_count = 0
                self._is_speech_active    = False
                self._vad_residual_len    = 0
                self._ring_write_idx      = 0   # evita audio fantasma alla riapertura
                return (None, pyaudio.paContinue)   # NON chiamare VAD, NON pubblicare

            # Transizione True→False: TTS appena terminato
            if tts_was and not tts_now:
                self._speech_frame_count  = 0
                self._silence_frame_count = 0
                self._is_speech_active    = False
                self._vad_residual_len    = 0
                self._ring_write_idx      = 0

            # ---------------------------------------------------------- #
            # Porcupine — wake word detection su segnale int16 grezzo
            # ---------------------------------------------------------- #
            is_listening = self._ev_listening.is_set()

            if not is_listening:
                porc_idx = 0
                
                # A. Gestione residuo dal callback precedente
                if self._porcupine_residual_len > 0:
                    needed = self.frame_length - self._porcupine_residual_len
                    if needed <= CHUNK_SIZE:
                        np.copyto(self._porcupine_assembly_buf[:self._porcupine_residual_len], 
                                  self._porcupine_residual_buf[:self._porcupine_residual_len])
                        np.copyto(self._porcupine_assembly_buf[self._porcupine_residual_len:], 
                                  self._int16_vad_buf[:needed])
                        
                        pcm = self._porcupine_assembly_buf.tolist()
                        result = self.porcupine.process(pcm)
                            
                        if result >= 0: self._on_wakeword_detected()
                        
                        porc_idx = needed
                        self._porcupine_residual_len = 0

                # B. Processa i blocchi interi nel chunk corrente
                while porc_idx + self.frame_length <= CHUNK_SIZE:
                    porcupine_frame = self._int16_vad_buf[porc_idx : porc_idx + self.frame_length]
                    
                    pcm = porcupine_frame.tolist()
                    result = self.porcupine.process(pcm)
                        
                    if result >= 0: self._on_wakeword_detected()
                    porc_idx += self.frame_length

                # C. Conserva il residuo finale
                rest = CHUNK_SIZE - porc_idx
                if rest > 0:
                    np.copyto(self._porcupine_residual_buf[:rest], self._int16_vad_buf[porc_idx:])
                    self._porcupine_residual_len = rest

                # Aggiorna is_listening se è stata rilevata la wake word nel loop
                is_listening = self._ev_listening.is_set()

            # ---------------------------------------------------------- #
            # [v3.0 — STEP C] VAD gate — solo se in ascolto
            # ---------------------------------------------------------- #
            if is_listening:
                # Parametro debug: se VAD gate disabilitato, pubblica direttamente
                if not self._cfg_enable_vad_gate:
                    self._publish_audio_frame(self._int16_vad_buf[:FRAME_SIZE])
                    self._consecutive_errors = 0
                    return (None, pyaudio.paContinue)

                # Gestione residuo inter-callback (attiva SEMPRE)
                start_idx = 0

                if self._vad_residual_len > 0:
                    needed = FRAME_SIZE - self._vad_residual_len
                    # [DSP-HOT] compone frame da residuo + inizio chunk corrente
                    np.copyto(self._assembly_buf[:self._vad_residual_len],
                              self._vad_residual_buf[:self._vad_residual_len])        # [DSP-HOT]
                    np.copyto(self._assembly_buf[self._vad_residual_len:],
                              self._int16_vad_buf[:needed])                            # [DSP-HOT]
                    self._process_vad_frame(self._assembly_buf)
                    start_idx = needed
                    self._vad_residual_len = 0

                i = start_idx
                while i + FRAME_SIZE <= CHUNK_SIZE:
                    self._process_vad_frame(self._int16_vad_buf[i:i + FRAME_SIZE])   # [DSP-HOT]
                    i += FRAME_SIZE

                residuo = CHUNK_SIZE - i
                if residuo > 0:
                    np.copyto(self._vad_residual_buf[:residuo],
                              self._int16_vad_buf[i:])                                # [DSP-HOT]
                    self._vad_residual_len = residuo

                # Heartbeat ogni 100 chunk (~60s a 960 campioni/chunk)
                self._stt_chunk_count += 1
                if self._stt_chunk_count % 100 == 0:
                    self.get_logger().info(
                        f"🎤 [VUI] VAD gate streaming audio (total chunks: {self._stt_chunk_count})")

            # [v2.5 #3] Frame elaborato correttamente: azzera contatore errori
            self._consecutive_errors = 0

        except Exception as e:
            self._consecutive_errors += 1

            if self._consecutive_errors == 1:
                self.get_logger().warning(f"Errore callback audio: {e}")
            elif self._consecutive_errors == _CALLBACK_ERROR_THRESHOLD:
                self.get_logger().fatal(
                    f"Errore callback audio persistente dopo "
                    f"{_CALLBACK_ERROR_THRESHOLD} frame consecutivi: {e}. "
                    f"Il nodo VUI potrebbe non funzionare correttamente."
                )
            elif self._consecutive_errors % 100 == 0:
                self.get_logger().error(
                    f"Errore callback audio #{self._consecutive_errors}: {e}")

        return (None, pyaudio.paContinue)

    # ------------------------------------------------------------------ #
    # Device discovery
    # ------------------------------------------------------------------ #
    def _find_audio_devices(self):
        in_idx = out_idx = None
        info       = self.pa.get_host_api_info_by_index(0)
        numdevices = info.get('deviceCount')

        self.get_logger().info("Dispositivi audio disponibili:")
        for i in range(numdevices):
            dev   = self.pa.get_device_info_by_host_api_device_index(0, i)
            name  = dev.get('name')
            n_in  = dev.get('maxInputChannels')
            n_out = dev.get('maxOutputChannels')
            self.get_logger().info(f"  [{i}] {name} (in:{n_in}, out:{n_out})")

            if self.device_name_target.lower() in name.lower():
                if n_in > 0 and in_idx is None:
                    in_idx = i
                if n_out > 0 and out_idx is None:
                    out_idx = i

        return in_idx, out_idx

    # ------------------------------------------------------------------ #
    # Shutdown
    # ------------------------------------------------------------------ #
    def destroy_node(self):
        self._shutdown = True
        try:
            self.get_logger().info("Spegnimento VUI Node...")
        except Exception:
            pass # Il contesto potrebbe essere già invalidato
        self._stop_listen_timer()
        if hasattr(self, '_playback_thread'):
            self._playback_thread.join(timeout=2.0)
            
        if hasattr(self, 'in_stream') and self.in_stream:
            self.in_stream.stop_stream()
            self.in_stream.close()
        if hasattr(self, 'out_stream') and self.out_stream:
            self.out_stream.stop_stream()
            self.out_stream.close()
            
        if hasattr(self, 'porcupine') and self.porcupine:
            self.porcupine.delete()
            
        if hasattr(self, 'pa'):
            self.pa.terminate()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    try:
        node = ReSpeakerVUINode()
        try:
            rclpy.spin(node)
        except (KeyboardInterrupt, rclpy.executors.ExternalShutdownException):
            pass
        finally:
            node.destroy_node()
    except Exception as e:
        # Fallback if logger is unavailable
        print(f"Errore fatale nel nodo VUI: {e}", file=sys.stderr)
    finally:
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()